// TermsConditionsPage.js
import React from 'react';
import { View, Text } from 'react-native';

const TermsConditionsPage = () => {
  return (
    <View>
      <Text>Terms and Conditions</Text>
      <Text>By using our service, you agree to these terms and conditions...</Text>
    </View>
  );
};
export default TermsConditionsPage;
