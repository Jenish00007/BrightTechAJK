// PrivacyPolicyPage.js
import React from 'react';
import { View, Text } from 'react-native';

const PrivacyPolicyPage = () => {
  return (
    <View>
      <Text>Privacy Policy</Text>
      <Text>Your privacy is important to us. Here's our privacy policy...</Text>
    </View>
  );
};

export default PrivacyPolicyPage;
